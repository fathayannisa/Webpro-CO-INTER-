<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel = "stylesheet" href="css/userScreen.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>
<body>
    <?php require_once("auth.php"); 
    include 'koneksi.php';

    $id_user = $_SESSION["users"]["id"];
    $user = mysqli_query($conn, "SELECT * from tb_user where id = $id_user");
    $listuser = mysqli_fetch_array($user);

    // buat nampili isi table berita
    $select = mysqli_query($conn, "SELECT * FROM berita ORDER BY tanggal DESC");
    $row = mysqli_fetch_assoc($select);
    $indeks_first = 0;
    
    // buat nampili isi table user
    $topic = mysqli_query($conn, "SELECT * FROM tb_forum ORDER BY tanggal DESC");
    $kumpulantopic= mysqli_fetch_assoc($topic);

    ?>
    <div id="side-nav">

        <div class= "judul">
            <h1>CO-INTER</h1>
        </div>

        <div class="informasi text-center">
        	<img src="img/<?php echo $listuser["image"]?>">
        	<h4><?php echo  $listuser["nama"] ?></h4>
        	<h5><?php echo  $listuser["nik"] ?></h5>
        	
        </div>

        <div class="content text-center">
            <ul>
            	<li>
            		<span><img src="img/home.png" width="20"></span>
            		<a href="index.php" style="text-decoration:none;color:black;">
                        <span style="font-size: 20px;">Home</span>
                    </a>
            	</li>
                <li>
            		<span><img src="img/home.png" width="20"></span>
                    <a href="editProfile.php" style="text-decoration:none;color:black;">
                        <span style="font-size: 20px;">Edit Profile</span>
                    </a>
            	</li>
            	<li>
                	<span><img src="img/profile2.png" width="20"></span>
            		<a href="fungsi_logout.php" style="text-decoration:none;color:black;">
                        <span style="font-size: 20px;">Logout
                        </span>
                    </a>
            	</li>
                
            </ul>
        </div>
        <div class="contact text-center">
        	<h4>Contact</h4>
        	<h5>+62099069009</h5>
        	<h5>Connect With Us</h5>

        	<ul>
        		<li><img src="img/Fb Black 1.png" width="35"></li>
        		<li><img src="img/IG Black 1.png" width="35"></li>
        		<li><img src="img/Twitter Black 1.png" width="35"></li>
            </ul>
        </div>
    </div>

    <div id="content">
        <div class="informasi-terkini">
            <div class="row">
                <div style="padding-bottom:4em;" class="col-sm-12">
                    <h1>Informasi Terkini</h1>
                    <div class="card-box">
                        <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
                            <div class="carousel-indicators">
                                <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                                <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
                                <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
                            </div>
                            <div class="carousel-inner">
                            
                                <div style="background-color:black;" class="carousel-item active">
                                    <img src=" <?php echo $row["gambar"] ?>" style="object-fit:cover;width:100%;height:400px;opacity:0.3;" class="d-block w-100" alt="...">
                                    <div class="carousel-caption d-none d-md-block">
                                        <h5><?php echo $row["judul"] ?></h5>
                                        <p><?php echo substr($row["deskripsi"],0,70)."........."; ?></p>
                                        <a href="detail_berita.php?id_berita=<?= $row['id_berita']; ?>"><button class="btn btn-primary">Detail</button></a>
                                    </div>
                                </div>
                                
                                <?php foreach($select as $isi) :?>
                                    <?php if ($indeks_first != 0) : ?> 
                                    <div style="background-color:black;" class="carousel-item">
                                        <img src="<?php echo $isi["gambar"] ?>" style="object-fit:cover;width:100%;height:400px;opacity:0.3;" class="d-block w-100" alt="...">
                                        <div class="carousel-caption d-none d-md-block">
                                            <h5><?php echo $isi["judul"] ?></h5>
                                            <p><?php echo substr($isi["deskripsi"],0,100)."........."; ?></p>
                                            <a href="detail_berita.php?id_berita=<?= $isi['id_berita']; ?>"><button class="btn btn-primary">Detail</button></a>
                                        </div>
                                    </div>
                                    <?php endif;?>
                                    <?php $indeks_first = $indeks_first + 1; ?>

                                <?php endforeach;?>
                            </div>
                            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                <span class="visually-hidden">Previous</span>
                            </button>
                            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                <span class="visually-hidden">Next</span>
                            </button>
                        </div>
                        
                    </div>
                </div>
                
        
                <div class="col-sm-6 umkm">
                    <h1>UMKM</h1>
                    <div class="card-box">
                        <div class="card-informasi">
                            <div class="row text-center">
                                
                                <div class="col-sm-6">
                                    <div class="card-box">
                                        <h5>Nasi Goreng Bude</h5>
                                        <img style="width: 100px;" src="img/nasgor.png" width="10">
                                        <p>
                                            Lokasi : Pasar Minggu
                                            <br>No.HP : 081293103
                                            <br>Jam Buka : 19.00 - 24.00
                                            
                                            <br>Nasi goreng rempah yang menjadikan menu favorite untuk setiap pelanggan.
                                        </p>
                                    </div>
                                </div>

                                <div class="col-sm-6">
                                    <div class="card-box">
                                        <h5>XiangLing Boba</h5>
                                        <img style="width: 100px;" src="img/boba.png" width="10">
                                        <p>
                                            Lokasi : Ruko Baru
                                            <br>No.HP : 0813390293
                                            <br>Jam Buka : 09.00 - 21.00
                                            
                                            <br>Diskon besar-besaran untuk pelanggan baru sebesar 50%.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class = "col-sm-6 forum">
                    <h1>Forum</h1>
                    <div class = "card-box text-center">
                        <div style = "display:flex; align-items: center;" class = "title">
                        <img src = "img/tambah.png" width="50px">
                        <h3 style = "margin-top: 10px; margin-left: 0.5em">
                            Tambah topik diskusi
                        </h3>
                    </div>
                    <?php $indeks_first = 0;?>
                    <?php foreach($topic as $isitopic) :?>
                        <?php if ($indeks_first < 3) : ?> 
                            <a style="text-decoration:none;color:black;"href="detail_forum.php?id_forum=<?= $kumpulantopic['id_forum']; ?>">
                            <div class = "topic text-center">
                                <h2><?php echo $isitopic['topik']?></h2>
                            </div>
                            </a>
                        <?php else : ?>
                            <a href=""><button style="margin-top:1em;" class="btn btn-primary"> Detail Here</button></a>
                        <?php endif ; ?>
                        <?php $indeks_first = $indeks_first + 1;?>
                    <?php endforeach;?>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</body>
</html>