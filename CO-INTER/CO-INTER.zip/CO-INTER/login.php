<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel = "stylesheet" href="css/login.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <title>Document</title>

</head>

<body>
    <div class="Navbar container">
        <div class="row">
            <div class="col-sm-6">
                <h1>CO-INTER</h1>
            </div>
            <div class="col-sm-6 text-end">
                <a href="login2.php"><button type="button" class="btn btn-dark">Login</button></a>
                <a href="register.php"><button type="button" class="btn btn-dark">Register</button></a>
            </div>
        </div>
    
    </div>

    <div class="Hero">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 text-center">
                    <img width="500" class="img-fluid" src= "img/Happy Spring 2 1.png">
                    <h1>COMMUNITY INFORMATION CENTER</h1>
                    <hr>
                    <h5>Layanan Pusat Informasi RT/RW</h5>
                </div>
            </div>
        </div>
    </div>

    <div class="Footer">
        <div class="container">
            <div class="row">
                <div class="col-sm-4 text-center">
                    
                    <h4>Contact</h4>
                    <h4>+628XXXXXX</h4>
                </div>

                <div class="col-sm-4 tittle-informtion text-center">
                    <h5>Another Information</h5>
                </div>

                <div class="col-sm-4 text-center">
                    <h4>Connect With Us</h4>
                    <ul>
                        <li><img src="IMG/Fb Black 1.png"></li>
                        <li><img src="IMG/IG Black 1.png"></li>
                        <li><img src="IMG/Twitter Black 1.png"></li>
                    </ul>
                </div>
                
            </div>
        </div>
    </div>
    
</body>
</html>