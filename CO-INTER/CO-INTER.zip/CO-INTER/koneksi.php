<?php
    $conn = mysqli_connect('localhost', 'root', '', 'db_co-inter');
    if (!$conn){
        echo "<script>
                alert('Failed Connect into Database');
            </script>";
    }
?>